# [CMath]([Python cmath Module](https://www.w3schools.com/python/module_cmath.asp))

| Method              | Description |
| ------------------- | ----------- |
| cmath.cos(x)        |             |
| cmath.acosh(x)      |             |
| cmath.asin(x)       |             |
| cmath.asinh(x)      |             |
| cmath.atan(x)       |             |
| cmath.atanh(x)      |             |
| cmath.cos(x)        |             |
| cmath.cosh(x)       |             |
| cmath.exp(x)        |             |
| cmath.isclose()     |             |
| cmath.isfinite(x)   |             |
| cmath.isnan(x)      |             |
| cmath.log(x[,base]) |             |
| cmath.log10(x)      |             |
| cmath.phase(x)      |             |
| cmath.polar(x)      |             |
| cmath.rect(x)       |             |
| cmath.sin(x)        |             |
| cmath.sinh(x)       |             |
| cmath.sqrt(x)       |             |
| cmath.tan(x)        |             |
| cmath.tanh(x)       |             |

---

## Constants

| Constant   | Description |
| ---------- | ----------- |
| cmath.e    |             |
| cmath.inf  |             |
| cmath.infj |             |
| cmath.nan  |             |
| cmath.nanj |             |
| cmath.pi   |             |
| cmath.tau  |             |
