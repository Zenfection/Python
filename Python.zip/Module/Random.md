# [Random]([Python Random Module](https://www.w3schools.com/python/module_random.asp))

| Method            | Description |
| ----------------- | ----------- |
| seed()            |             |
| getstate()        |             |
| setstate()        |             |
| getrandbits()     |             |
| randrange()       |             |
| randint()         |             |
| choice()          |             |
| choices()         |             |
| shuffle()         |             |
| sample()          |             |
| random()          |             |
| uniform()         |             |
| triangular()      |             |
| betavariate()     |             |
| expovariate()     |             |
| gammavariate()    |             |
| gauss()           |             |
| lognormvariate()  |             |
| normalvariate()   |             |
| vonmisesvariate() |             |
| paretovariate()   |             |
| weibullvariate()  |             |
