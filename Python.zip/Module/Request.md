# [Request]([Python Requests Module](https://www.w3schools.com/python/module_requests.asp))

| Method                      | Description |
| --------------------------- | ----------- |
| delete(url, args)           |             |
| get(url, params, args)      |             |
| head(url, args)             |             |
| patch(url, data, args)      |             |
| post(url, data, json, args) |             |
| put(url, data, args)        |             |
| request(method, url, args)  |             |
