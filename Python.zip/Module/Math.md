# [Math]([Python math Module](https://www.w3schools.com/python/module_math.asp))

| Method           | Description |
| ---------------- | ----------- |
| math.acos()      |             |
| math.acosh()     |             |
| math.asin()      |             |
| math.asinh()     |             |
| math.atan()      |             |
| math.atan2()     |             |
| math.atanh()     |             |
| math.cell()      |             |
| math.comb()      |             |
| math.copysign()  |             |
| math.cos()       |             |
| math.cosh()      |             |
| math.degree()    |             |
| math.dist()      |             |
| math.ef()        |             |
| math.erfc()      |             |
| math.exp()       |             |
| math.expm1()     |             |
| math.fabs()      |             |
| math.factorial() |             |
| math.floor()     |             |
| math.fmod()      |             |
| math.frexp()     |             |
| math.fsum()      |             |
| math.gamma()     |             |
| math.gcd()       |             |
| math.hypot()     |             |
| math.isclose()   |             |
| math.isfinite()  |             |
| math.isinf()     |             |
| math.isnan()     |             |
| math.ldexp()     |             |
| math.lgamma()    |             |
| math.log()       |             |
| math.log10()     |             |
| math.log1p()     |             |
| math.log2()      |             |
| math.perm()      |             |
| math.pow()       |             |
| math.pord()      |             |
| math.radians()   |             |
| math.remainder() |             |
| math.sin()       |             |
| math.sinh()      |             |
| math.sqrt()      |             |
| math.tan()       |             |
| math.tanh()      |             |
| math.trunc()     |             |

---

## Math Constrant

| Constant | Description |
| -------- | ----------- |
| math.e   |             |
| math.inf |             |
| math.nan |             |
| math.pi  |             |
| math.tau |             |
