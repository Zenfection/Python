# [Exceptions]([Python Built-in Exceptions](https://www.w3schools.com/python/python_ref_exceptions.asp))

| Exception             | Description |
| --------------------- | ----------- |
| ArithmeticError       |             |
| AssertionError        |             |
| AttributeError        |             |
| Exception             |             |
| EOFError              |             |
| FloatingPointError    |             |
| GeneratorExit         |             |
| ImportError           |             |
| Indentation           |             |
| IndexError            |             |
| KeyError              |             |
| KeyboardInterrupt     |             |
| LookupError           |             |
| MemoryError           |             |
| NameError             |             |
| NotImplementedError   |             |
| OSError               |             |
| OverflowError         |             |
| ReferenceError        |             |
| RuntimeError          |             |
| StopIteration         |             |
| SyntaxError           |             |
| TabError              |             |
| TypeError             |             |
| UnboundLocalError     |             |
| UnicodeError          |             |
| UnicodeEncodeError    |             |
| UnicodeTranslateError |             |
| ValueError            |             |
| ZeroDivisionError     |             |


