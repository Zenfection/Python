# [Keywords]([Python Keywords](https://www.w3schools.com/python/python_ref_keywords.asp))

| Keyword  | Description |
| -------- | ----------- |
| and      |             |
| as       |             |
| assert   |             |
| break    |             |
| class    |             |
| continue |             |
| def      |             |
| del      |             |
| elif     |             |
| else     |             |
| except   |             |
| False    |             |
| finally  |             |
| for      |             |
| form     |             |
| global   |             |
| if       |             |
| import   |             |
| in       |             |
| is       |             |
| lambda   |             |
| None     |             |
| nonlocal |             |
| not      |             |
| or       |             |
| pass     |             |
| return   |             |
| True     |             |
| try      |             |
| while    |             |
| with     |             |
| yield    |             |
