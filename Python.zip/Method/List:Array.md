# [List]([Python List/Array Methods](https://www.w3schools.com/python/python_ref_list.asp))

| Method    | Description |
| --------- | ----------- |
| append()  |             |
| clear()   |             |
| copy()    |             |
| extend()  |             |
| index()   |             |
| insert()  |             |
| pop()     |             |
| remove()  |             |
| reverse() |             |
| sort()    |             |

---

# [Dictionary Method]([Python Dictionary Methods](https://www.w3schools.com/python/python_ref_dictionary.asp))

| Method       | Description |
| ------------ | ----------- |
| clear()      |             |
| copy()       |             |
| fromkeys()   |             |
| get()        |             |
| items()      |             |
| keys()       |             |
| pop()        |             |
| popitem()    |             |
| setdefault() |             |
| update()     |             |
| values()     |             |

---

# [Tuple Methods]([Python Tuple Methods](https://www.w3schools.com/python/python_ref_tuple.asp))

| Method  | Description |
| ------- | ----------- |
| count() |             |
| index() |             |

---

# [Set Methods]([Python Set Methods](https://www.w3schools.com/python/python_ref_set.asp))

| Method                        | Description |
| ----------------------------- | ----------- |
| add()                         |             |
| clear()                       |             |
| copy()                        |             |
| difference()                  |             |
| difference_update()           |             |
| discard()                     |             |
| intersection_update           |             |
| isdisjoint()                  |             |
| issubset()                    |             |
| issuperset()                  |             |
| pop()                         |             |
| remove()                      |             |
| symmetric_difference          |             |
| symmetric_difference_update() |             |
| union()                       |             |
| update()                      |             |
