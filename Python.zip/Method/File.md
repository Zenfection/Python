# [File Methods]([Python File Methods](https://www.w3schools.com/python/python_ref_file.asp))

| Method       | Description |
| ------------ | ----------- |
| close()      |             |
| detach()     |             |
| fileno()     |             |
| flush()      |             |
| isatty()     |             |
| read()       |             |
| readable()   |             |
| readline()   |             |
| readlines()  |             |
| seekable()   |             |
| tell()       |             |
| truncate()   |             |
| writable()   |             |
| write()      |             |
| writelines() |             |
