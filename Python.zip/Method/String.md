# [String Methods]([Python String Methods](https://www.w3schools.com/python/python_ref_string.asp))

| Method         | Description |
| -------------- | ----------- |
| capitalize()   |             |
| casefold()     |             |
| center()       |             |
| count()        |             |
| encode()       |             |
| endswith()     |             |
| expandtabs()   |             |
| find()         |             |
| format()       |             |
| format_map()   |             |
| index()        |             |
| isalpha()      |             |
| isdecimal()    |             |
| isdigit()      |             |
| isidentifier() |             |
| islower()      |             |
| isnumeric()    |             |
| isprintable()  |             |
| isspace()      |             |
| istitle()      |             |
| isupper()      |             |
| join()         |             |
| ljust()        |             |
| lower()        |             |
| lstrip()       |             |
| maketrans()    |             |
| partition()    |             |
| replace()      |             |
| rfind()        |             |
| rindex()       |             |
| rjust()        |             |
| rsplit()       |             |
| splitlines()   |             |
| startswith()   |             |
| strip()        |             |
| swapcase()     |             |
| title()        |             |
| translate()    |             |
| upper()        |             |
| zfill()        |             |
